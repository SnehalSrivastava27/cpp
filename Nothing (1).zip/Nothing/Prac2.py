import networkx as nx
import matplotlib.pyplot as plt

G = nx.karate_club_graph()

print("=== GLOBAL NETWORK PROPERTIES ===")
print(f"Total Nodes: {G.number_of_nodes()}")
print(f"Total Edges: {G.number_of_edges()}")
print(f"Network Density: {nx.density(G):.4f}")
print(f"Average Clustering Coefficient: {nx.average_clustering(G):.4f}")

if nx.is_connected(G):
    print(f"Network Diameter: {nx.diameter(G)}")
    print(f"Average Shortest Path Length: {nx.average_shortest_path_length(G):.4f}")
else:
    print("Network is disconnected; cannot compute global path length or diameter.")

print("\n=== LOCAL PROPERTIES (Example: Node 0) ===")
node_id = 0
print(f"Degree of Node {node_id}: {G.degree(node_id)}")
print(f"Clustering Coefficient of Node {node_id}: {nx.clustering(G, node_id):.4f}")

degree_sequence = [degree for node, degree in G.degree()]

degree_counts = {}
for d in degree_sequence:
    degree_counts[d] = degree_counts.get(d, 0) + 1

degrees = sorted(degree_counts.keys())
counts = [degree_counts[d] for d in degrees]

plt.figure(figsize=(8, 5))
plt.bar(degrees, counts, color='coral', edgecolor='black')

plt.title("Degree Distribution of the Network")
plt.xlabel("Degree (Number of Connections)")
plt.ylabel("Frequency (Number of Nodes)")
plt.xticks(range(min(degrees), max(degrees) + 1))
plt.grid(axis='y', linestyle='--', alpha=0.7)

plt.show()