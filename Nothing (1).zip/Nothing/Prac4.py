import networkx as nx
import scipy.stats as stats

G = nx.karate_club_graph()

N = 5 

degree_cent = nx.degree_centrality(G)
between_cent = nx.betweenness_centrality(G)
close_cent = nx.closeness_centrality(G)
page_rank = nx.pagerank(G)

def get_top_n(name, centrality_dict, n):
    sorted_nodes = sorted(centrality_dict, key=centrality_dict.get, reverse=True)
    top_nodes = sorted_nodes[:n]
    print(f"Top {n} by {name:<22}: {top_nodes}")

print("=== TOP N NODES ===")
get_top_n("Degree Centrality", degree_cent, N)
get_top_n("Betweenness Centrality", between_cent, N)
get_top_n("Closeness Centrality", close_cent, N)
get_top_n("PageRank", page_rank, N)

nodes = list(G.nodes())

pr_scores    = [page_rank[node] for node in nodes]
deg_scores   = [degree_cent[node] for node in nodes]
bet_scores   = [between_cent[node] for node in nodes]
close_scores = [close_cent[node] for node in nodes]

corr_deg = stats.spearmanr(pr_scores, deg_scores)[0]
corr_bet = stats.spearmanr(pr_scores, bet_scores)[0]
corr_close = stats.spearmanr(pr_scores, close_scores)[0]

print("\n=== RANK CORRELATION WITH PAGERANK ===")
print(f"PageRank vs Degree Centrality:      {corr_deg:.4f}")
print(f"PageRank vs Betweenness Centrality: {corr_bet:.4f}")
print(f"PageRank vs Closeness Centrality:   {corr_close:.4f}")