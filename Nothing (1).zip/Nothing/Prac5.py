import networkx as nx
from networkx.algorithms import community
import matplotlib.pyplot as plt
import numpy as np

G = nx.karate_club_graph()

algo1_communities = list(community.greedy_modularity_communities(G))
algo2_communities = list(community.label_propagation_communities(G))

def get_node_colors(graph, communities):
    color_map = []
    for node in graph.nodes():
        for i, comm in enumerate(communities):
            if node in comm:
                color_map.append(i)
    return color_map

pos = nx.spring_layout(G, seed=42)
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
nx.draw(
    G,
    pos,
    node_color=get_node_colors(G, algo1_communities),
    cmap=plt.cm.Set1,
    with_labels=True,
    node_size=500
)
plt.title("Algorithm 1: Greedy Modularity")

plt.subplot(1, 2, 2)
nx.draw(
    G,
    pos,
    node_color=get_node_colors(G, algo2_communities),
    cmap=plt.cm.Set1,
    with_labels=True,
    node_size=500
)
plt.title("Algorithm 2: Label Propagation")

plt.tight_layout()
plt.show()

mod1 = community.modularity(G, algo1_communities)
mod2 = community.modularity(G, algo2_communities)

cov1 = community.partition_quality(G, algo1_communities)[0]
cov2 = community.partition_quality(G, algo2_communities)[0]

labels = ['Greedy Modularity', 'Label Propagation']
modularity_scores = [mod1, mod2]
coverage_scores = [cov1, cov2]

x = np.arange(len(labels))
width = 0.35

plt.figure(figsize=(8, 6))
plt.bar(x - width/2, modularity_scores, width, label='Modularity', color='skyblue', edgecolor='black')
plt.bar(x + width/2, coverage_scores, width, label='Coverage', color='coral', edgecolor='black')

plt.ylabel('Scores (0.0 to 1.0)')
plt.title('Comparison of Community Detection Algorithms')
plt.xticks(x, labels)
plt.legend()
plt.ylim(0, 1.1)

plt.show()