import networkx as nx
import matplotlib.pyplot as plt
import random

base_graph = nx.karate_club_graph()
G = base_graph.to_directed()

for u, v in G.edges():
    G[u][v]['weight'] = random.randint(1, 5)

node_sizes = [G.degree(node) * 100 for node in G.nodes()]
edge_widths = [G[u][v]['weight'] for u, v in G.edges()]

plt.figure(figsize=(10, 8))

pos = nx.spring_layout(G, seed=42)

nx.draw(
    G, 
    pos, 
    with_labels=True,
    node_color='lightblue',
    node_size=node_sizes,
    width=edge_widths,
    edge_color='gray',
    arrowsize=15
)

plt.title("Weighted Directed Network\n(Node Size ∝ Degree, Edge Width ∝ Weight)")
plt.show()