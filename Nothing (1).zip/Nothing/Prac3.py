import networkx as nx

N = 1000

G_random = nx.erdos_renyi_graph(n=N, p=0.01, seed=42)
G_small_world = nx.watts_strogatz_graph(n=N, k=10, p=0.1, seed=42)
G_pref_attach = nx.barabasi_albert_graph(n=N, m=5, seed=42)

networks = {
    "Random (Erdős-Rényi)": G_random,
    "Small World (Watts-Strogatz)": G_small_world,
    "Pref. Attachment (Barabási-Albert)": G_pref_attach
}

print(f"{'Network Model':<35} | {'Avg Clustering':<15} | {'Avg Path Length'}")
print("-" * 75)

for name, G in networks.items():
    clustering = nx.average_clustering(G)
    
    if nx.is_connected(G):
        path_len = nx.average_shortest_path_length(G)
        path_str = f"{path_len:.4f}"
    else:
        largest_cc = max(nx.connected_components(G), key=len)
        subgraph = G.subgraph(largest_cc)
        path_len = nx.average_shortest_path_length(subgraph)
        path_str = f"{path_len:.4f} (Largest Component only)"
        
    print(f"{name:<35} | {clustering:<15.4f} | {path_str}")