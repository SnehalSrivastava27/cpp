import networkx as nx
import matplotlib.pyplot as plt
import random

G = nx.karate_club_graph()
nodes = list(G.nodes())

beta = 0.3
gamma = 0.1
steps = 20

def simulate_SI(graph, beta, steps):
    states = {n: 0 for n in graph.nodes()}
    
    patient_zero = random.choice(nodes)
    states[patient_zero] = 1
    
    trend_S, trend_I = [], []
    
    for t in range(steps):
        trend_S.append(list(states.values()).count(0))
        trend_I.append(list(states.values()).count(1))
        
        new_infected = []
        for node in graph.nodes():
            if states[node] == 1:
                for neighbor in graph.neighbors(node):
                    if states[neighbor] == 0:
                        if random.random() < beta:
                            new_infected.append(neighbor)
        
        for n in new_infected:
            states[n] = 1
            
    return trend_S, trend_I

def simulate_SIR(graph, beta, gamma, steps):
    states = {n: 0 for n in graph.nodes()}
    states[random.choice(nodes)] = 1
    
    trend_S, trend_I, trend_R = [], [], []
    
    for t in range(steps):
        trend_S.append(list(states.values()).count(0))
        trend_I.append(list(states.values()).count(1))
        trend_R.append(list(states.values()).count(2))
        
        new_infected = []
        new_recovered = []
        
        for node in graph.nodes():
            if states[node] == 1:
                for neighbor in graph.neighbors(node):
                    if states[neighbor] == 0:
                        if random.random() < beta:
                            new_infected.append(neighbor)
                
                if random.random() < gamma:
                    new_recovered.append(node)
                    
        for n in new_infected:
            states[n] = 1
        for n in new_recovered:
            states[n] = 2
            
    return trend_S, trend_I, trend_R

si_S, si_I = simulate_SI(G, beta, steps)
sir_S, sir_I, sir_R = simulate_SIR(G, beta, gamma, steps)

plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(si_S, label='Susceptible', color='blue', marker='o')
plt.plot(si_I, label='Infected', color='red', marker='o')
plt.title("SI Model Diffusion Trend")
plt.xlabel("Time Step")
plt.ylabel("Number of Nodes")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)

plt.subplot(1, 2, 2)
plt.plot(sir_S, label='Susceptible', color='blue', marker='o')
plt.plot(sir_I, label='Infected', color='red', marker='o')
plt.plot(sir_R, label='Recovered', color='green', marker='o')
plt.title("SIR Model Diffusion Trend")
plt.xlabel("Time Step")
plt.ylabel("Number of Nodes")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)

plt.tight_layout()
plt.show()