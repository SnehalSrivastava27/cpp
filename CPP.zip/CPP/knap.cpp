#include <iostream>
#include <vector>
using namespace std;
int f(int ind,int W,vector <int> &weight, vector<int> &val)
{
    if(ind==0)
    {
        if(weight[0]<=W)
        return val[0];
        return 0;
    }
        int notTake=0 + f(ind-1,W,weight,val);
        int take= INT_MIN;
        if(weight[ind]<=W)
        {
            take=val[ind]+f(ind-1,W-weight[ind],weight,val);
        }
        return max(take,notTake);
}
int knapsack(vector <int> weight, vector <int> val,int n, int maxWeight)
{
    return f(n-1,maxWeight,weight,val);
}
int main() {
    vector<int> weight;
    weight.push_back(1);
    weight.push_back(3);
    weight.push_back(4);
    weight.push_back(5);

    vector<int> value;
    value.push_back(10);
    value.push_back(40);
    value.push_back(50);
    value.push_back(70);

    int maxWeight = 8;
    int n = weight.size();

    int maxVal = knapsack(weight, value, n, maxWeight);
    cout << "Maximum value in Knapsack = " << maxVal << endl;

    return 0;
}