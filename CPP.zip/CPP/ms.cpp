#include <iostream>
using namespace std;
int comparisonCount = 0;
void Merge(int A[],int l, int mid, int h)
{
    int i=l;
    int j=mid+1;
    int k=l;
    int B[100];
    while(i<=mid && j<=h)
    {
        comparisonCount+=1;
        if(A[i]<A[j])
        {
            B[k++]=A[i++];
        }
        else{
            B[k++]=A[j++];
        }
    }
    //remaining copy
    for(;i<=mid;i++)
    {
        B[k++]=A[i];
    }
    for(;j<=h;j++)
    {
        B[k++]=A[j];
    } 
    //transfer back to B
    for(i=l;i<=h;i++)
    {
        A[i]=B[i];
    }
}
void MergeSort(int A[],int l, int h)
{
    int mid;
    if(l<h)
    {
        mid=(l+h)/2;
        MergeSort(A,l,mid);
        MergeSort(A,mid+1,h);
        Merge(A,l,mid,h);
    }
}
int main()
{
    int a[]={6,7,2,1,3,4,9,0,10};
    int n=9;
    int i;
    MergeSort(a,0,8);
    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<comparisonCount;
}