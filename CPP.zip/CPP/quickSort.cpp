#include <iostream>
using namespace std;

int c =0;

void printArray(int Ar[], int size) {
    for (int i = 0; i < size; i++) {
        cout << Ar[i] << " ";
    }
    cout << endl;
}

int partition(int Ar[], int s, int e){
    int pivot=Ar[e]; 
    int i =s-1;
    for (int j=s; j<e; j++){
        c++;
        if (Ar[j] <= pivot){ 
            i++;
            int temp =Ar[i];
            Ar[i] =Ar[j];
            Ar[j] =temp;
        }
    }
    int temp=Ar[i + 1];
    Ar[i + 1]=Ar[e];
    Ar[e]=temp;

    return i + 1; 
}

void quicksort(int Ar[], int s, int e) {
    if (s < e) {
        int q = partition(Ar, s, e);
        quicksort(Ar, s, q - 1);
        quicksort(Ar, q + 1, e);
    }
}


int main() {
    int arr[]= {5,3,6,4};
    int n=4;

    quicksort(arr, 0, n - 1);

    cout << "Sorted array: ";
    printArray(arr, n);

    cout<<"Number of comparisoms: "<<c<<endl;

    return 0;
}

