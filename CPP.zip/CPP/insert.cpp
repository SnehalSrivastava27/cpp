#include <iostream>
using namespace std;

void insertionSort(int arr[], int n, int &comparisons) {
    comparisons = 0; 

    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j;
        for (j = i - 1; j >= 0; j--) {
            comparisons++; 
            if (arr[j] > key)
                arr[j + 1] = arr[j];
            else
                break; 
        }
        arr[j + 1] = key;
    }
}

int main() {
    int arr[] = {4,3,2,1,0};
    int n = sizeof(arr) / sizeof(arr[0]);
    int comparisons = 0;

    insertionSort(arr, n, comparisons);

    cout << "Sorted array: ";
    for (int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << "\nTotal comparisons: " << comparisons << endl;

    return 0;
}
