#include <iostream>
#include <queue>
using namespace std;

void BFS(int G[][7],int start,int n)
{
    int i=start;
    queue<int> q;
    int Visited[7]={0,0,0,0,0,0,0};
    cout<<"BFS"<<endl;
    cout<<i<<endl;
    Visited[i]=1;
    q.push(i);
    while(!q.empty())
    {
        i=q.front();
        q.pop();
        for(int j=1;j<=n;j++)
        {
            if(G[i][j]==1 && Visited[j]==0)
            {
                cout<<j<<endl;
                Visited[j]=1;
                q.push(j);
            }
        }
    }

}
void DFS(int G[][7],int start,int n)
{
    static int visited[7]={0,0,0,0,0,0,0};
    if(visited[start]==0)
    {
        cout<<start<<endl;
        visited[start]= 1;

        for(int j=1;j<n;j++)
        {
            if(G[start][j]==1 && visited[j]==0)
            {
                DFS(G,j,n);
            }
        }
    }
}
int main()
{
    int G[7][7]={
        {0,0,0,0,0,0,0},
        {0,0,1,1,0,0,0},
        {0,1,0,0,1,0,0},
        {0,1,0,0,1,0,0},
        {0,0,1,1,0,1,1},
        {0,0,0,0,1,0,0},
        {0,0,0,0,1,0,0},
    };
    DFS(G,1,7);
}