    for(int i=0; i<leftSize; i++){
        left[i] = ar[start + i];
    }
    for(int i=0; i<rightSize; i++){
        right[i] = ar[mid+1+i];
    }
