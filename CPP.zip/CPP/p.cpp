#include <iostream>
#include <climits>
using namespace std;

#define I INT_MAX
const int N = 8;

int cost[N][N] = {
    {I,I,I,I,I,I,I,I},
    {I,I,25,I,I,I,15,I},
    {I,25,I,12,I,I,I,10},
    {I,I,12,I,8,I,I,I},
    {I,I,I,8,I,16,I,14},
    {I,I,I,I,16,I,20,18},
    {I,15,I,I,I,20,I,I},
    {I,I,10,I,14,18,I,I}
};

int near[N];
int t[2][N-1];

int main() {
    int u, v, n = 7, min = I,k=-1;
    for (int i = 0; i < N; i++) near[i] = I;

    // Step 1: Find the minimum cost edge
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (cost[i][j] < min) {
                min = cost[i][j];
                u = i;
                v = j;
            }
        }
    }

    t[0][0] = u;
    t[1][0] = v;
    near[u] = near[v] = 0;

    for (int i = 1; i <= n; i++) {
        if (near[i] != 0) {
            near[i] = (cost[i][u] < cost[i][v]) ? u : v;
        }
    }

    // Prim's Algorithm core
    for (int i = 1; i < n - 1; i++) {
        min = I;
        for (int j = 1; j <= n; j++) {
            if (near[j] != 0 && cost[j][near[j]] < min) {
                k = j;
                min = cost[j][near[j]];
            }
        }

        if (k == -1) {
            cout << "Error: No more valid edges.\n";
            break;
        }

        t[0][i] = k;
        t[1][i] = near[k];
        near[k] = 0;

        for (int j = 1; j <= n; j++) {
            if (near[j] != 0 && cost[j][k] < cost[j][near[j]]) {
                near[j] = k;
            }
        }
    }

    // Output MST
    for (int i = 0; i < n - 1; i++) {
        cout << t[0][i] << " - " << t[1][i] << endl;
    }

    return 0;
}
