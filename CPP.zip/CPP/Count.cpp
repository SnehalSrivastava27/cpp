#include <iostream>
using namespace std;

void countSort(int arr[], int n) {
    int k = arr[0];
    for (int i = 0; i < n; i++) {
        k = max(k, arr[i]);
    } // max ke liye
    // isse array ki length decide hogi count wale ki

    int* count = new int[k + 1](); // sab zero se initialized
    int* output = new int[n];

    for (int i = 0; i < n; i++) {
        count[arr[i]]++;
    }  // freq count banane ke liye
    // yeh aise work kr rha let say array is [4,2,2,8,3]        so here c[4]++ c[2]++ c[2]++ c[8]++ c[3]++

    for (int i = 1; i <= k; i++) {
        count[i] += count[i - 1];
    }
    // cumulative count krne ke liye
    // cum count ke liye [0,0,2,3,4,4,4,4,5]

    for (int i = n - 1; i >= 0; i--) {
        output[--count[arr[i]]] = arr[i];
    }
    

    for (int i = 0; i < n; i++) {
        arr[i] = output[i];
    }

    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    int n;
    cout << "Enter input size: ";
    cin >> n;

    int* arr = new int[n];
    for (int i = 0; i < n; i++) {
        cout << "Enter " << i + 1 << " element: ";
        cin >> arr[i];
    }

    countSort(arr, n);
    return 0;
}
