start :-
    write('Enter a number: '),
    read(N),

    fib(N, T),

    write('Fibonacci number is: '),
    write(T).

fib(0, 0) :- !.
fib(1, 1) :- !.
fib(N, T) :-
    N > 1,
    N1 is N - 1,
    N2 is N - 2,

    fib(N1, T1),
    fib(N2, T2),

    T is T1 + T2.

% ============================================================
% FIBONACCI
% ============================================================

% fib/2 computes the Nth Fibonacci number.
% fib(N, T) where T is the Nth term.

% BASE CASE 1:
% fib(0, 0) :- !.
% Fibonacci of 0 is 0.
% Cut (!) prevents backtracking after this match.

% BASE CASE 2:
% fib(1, 1) :- !.
% Fibonacci of 1 is 1.
% Cut (!) prevents backtracking after this match.

% RECURSIVE CASE:
% fib(N, T) :-
%     N > 1,
%     N1 is N - 1,
%     N2 is N - 2,
%     fib(N1, T1),
%     fib(N2, T2),
%     T is T1 + T2.
% For N > 1, two sub-problems are solved independently.
% fib(N-1) stored in T1, fib(N-2) stored in T2.
% Final result T = T1 + T2.

% TRACE: fib(4, T)
% fib(4) = fib(3)        + fib(2)
%        = (fib(2)+fib(1)) + (fib(1)+fib(0))
%        = ((1+0) + 1)   + (1+0)
%        =     2          +   1   = 3