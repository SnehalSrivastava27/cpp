start :-
    write('Enter a number: '),
    read(N),

    factorial(N, F),

    write('Factorial is: '),
    write(F).

factorial(0, 1).
factorial(N, F) :-
    N > 0,
    N1 is N - 1,
    factorial(N1, F1),
    F is N * F1.

% ============================================================
% FACTORIAL
% ============================================================

% factorial/2 computes factorial of N.
% factorial(N, F) where F = N!

% BASE CASE:
% factorial(0, 1).
% Factorial of 0 is 1 by mathematical definition.
% Recursion stops here.

% RECURSIVE CASE:
% factorial(N, F) :-
%     N > 0,
%     N1 is N - 1,
%     factorial(N1, F1),
%     F is N * F1.
% N must be greater than 0.
% N1 = N - 1 (next smaller number).
% Recursively compute factorial of N1 and store in F1.
% Multiply N * F1 to get current factorial F.

% TRACE: factorial(3, F)
% factorial(3,F) → 3 * factorial(2,F1)
%                      → 2 * factorial(1,F2)
%                               → 1 * factorial(0,F3)
%                                       F3 = 1  ← BASE
%                               F2 = 1*1 = 1
%                      F1 = 2*1 = 2
%               F  = 3*2 = 6