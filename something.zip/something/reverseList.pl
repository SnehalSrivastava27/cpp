start :-
    write('Enter a list: '),
    read(L),

    reverse(L, R),

    write('Reversed list is: '),
    write(R).

reverse([], []).
reverse([H|T], R) :-
    reverse(T, RT),
    conc(RT, [H], R).

conc([], L, L).
conc([H|T], L, [H|R]) :-
    conc(T, L, R).

% ============================================================
% REVERSE LIST
% ============================================================

% reverse/2 reverses a list.
% reverse(List, Reversed)

% BASE CASE:
% reverse([], []).
% Reverse of an empty list is an empty list.

% RECURSIVE CASE:
% reverse([H|T], R) :-
%     reverse(T, RT),
%     conc(RT, [H], R).
% Head H is separated from Tail T.
% Tail T is reversed recursively into RT.
% Then H is appended at the END using conc/3.
% This places Head at the back, building reverse order.

% conc/3 here is the same list concatenation predicate.
% conc([], L, L).           ← base case
% conc([H|T], L, [H|R]) :- conc(T, L, R).   ← recursive

% TRACE: reverse([1,2,3], R)
% reverse([2,3], RT1), conc(RT1,[1],R)
%   reverse([3], RT2), conc(RT2,[2],RT1)
%     reverse([], RT3), conc(RT3,[3],RT2)
%       RT3=[]  ← BASE
%     RT2 = [3]
%   RT1 = [3,2]
% R   = [3,2,1]