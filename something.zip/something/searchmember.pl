start :-
    write('Enter element: '),
    read(X),

    write('Enter list: '),
    read(L),

    memb(X, L),
    write('Element is present in the list.').

memb(X, [X|_]) :- !.
memb(X, [H|T]) :-
    memb(X, T).

% ============================================================
% SEARCH MEMBER
% ============================================================

% memb/2 checks if element X exists in the list.
% memb(Element, List)

% BASE CASE:
% memb(X, [X|_]) :- !.
% If X matches the Head of the list, it is found. TRUE.
% Cut (!) stops any further searching once found.
% Underscore (_) means we don't care about the rest of list.

% RECURSIVE CASE:
% memb(X, [H|T]) :- memb(X, T).
% If X does NOT match the Head H,
% search continues recursively in the Tail T.
% Note: H is present but never used (irrelevant element).
% If list becomes empty and X not found → predicate FAILS.