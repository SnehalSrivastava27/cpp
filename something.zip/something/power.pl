start :-
    write('Enter the number: '),
    read(Num),

    write('Enter the power: '),
    read(Pow),

    power(Num, Pow, Ans),

    write('Answer is: '),
    write(Ans).

power(_, 0, 1) :- !.
power(Num, Pow, Ans) :-
    Pow > 0,
    Pow1 is Pow - 1,
    power(Num, Pow1, Ans1),
    Ans is Num * Ans1.

% ============================================================
% POWER
% ============================================================

% power/3 computes Num raised to the power Pow.
% power(Num, Pow, Ans)

% BASE CASE:
% power(_, 0, 1) :- !.
% Any number raised to power 0 is 1.
% Underscore (_) means base number is irrelevant here.
% Cut (!) stops backtracking after this match.

% RECURSIVE CASE:
% power(Num, Pow, Ans) :-
%     Pow > 0,
%     Pow1 is Pow - 1,
%     power(Num, Pow1, Ans1),
%     Ans is Num * Ans1.
% Pow must be greater than 0.
% Pow1 = Pow - 1 (decrement exponent by 1).
% Recursively compute Num^(Pow-1) into Ans1.
% Multiply Num * Ans1 to get current result Ans.

% TRACE: power(2, 3, Ans)
% power(2,3) → 2 * power(2,2,A1)
%                   → 2 * power(2,1,A2)
%                             → 2 * power(2,0,A3)
%                                       A3=1  ← BASE
%                             A2 = 2*1 = 2
%                   A1 = 2*2 = 4
%               Ans = 2*4 = 8