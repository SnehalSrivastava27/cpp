start :-
    write('Enter first number: '),
    read(N1),

    write('Enter second number: '),
    read(N2),

    multiply(N1, N2, R),

    write('Multiply is: '),
    write(R).

    multiply(N1, N2, R) :-
    R is N1 * N2.

% ============================================================
% MULTIPLY
% ============================================================

% multiply/3 multiplies two numbers.
% multiply(N1, N2, R)

% SINGLE CLAUSE:
% multiply(N1, N2, R) :-
%     R is N1 * N2.
% No recursion needed here.
% Prolog's built-in 'is' evaluates the arithmetic expression.
% R is directly unified with the product N1 * N2.