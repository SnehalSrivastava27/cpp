start :-
    write('Enter a list: '),
    read(L),

    ( evenlength(L) ->
        write('List has even length')
    ;
        write('List has odd length')
    ).

evenlength([]).
evenlength([_,_|T]) :-
    evenlength(T).

oddlength([_]).
oddlength([_,_|T]) :-
    oddlength(T).
    
% ============================================================
% EVEN & ODD LENGTH LIST
% ============================================================

% evenlength/1 - checks if list has even number of elements.

% BASE CASE:
% evenlength([]).
% Empty list has 0 elements, 0 is even. TRUE.

% RECURSIVE CASE:
% evenlength([_,_|T]) :- evenlength(T).
% Two elements are stripped at a time from the list.
% Recursion continues on Tail (T).
% If list empties exactly → even length.
% If one element is left over → fails (not even).

% ---
% oddlength/1 - checks if list has odd number of elements.

% BASE CASE:
% oddlength([_]).
% A single-element list is odd. TRUE. Recursion stops here.

% RECURSIVE CASE:
% oddlength([_,_|T]) :- oddlength(T).
% Two elements stripped at a time.
% Recursion stops when exactly one element remains.