start:-
write('Enter first number: '), read(N1),
write('Enter second number: '), read(N2),

max(N1, N2, M),
write('Maximum is: '), write(M).

max(X, Y, X) :- X > Y. !.
max(X, Y, Y).

% ============================================================
% MAXIMUM OF TWO NUMBERS
% ============================================================

% max/3 finds the maximum between two numbers.
% max(X, Y, Max)

% CASE 1:
% max(X, Y, X) :- X > Y. !.
% If X is greater than Y, result is X.
% Cut (!) prevents falling through to Case 2.

% CASE 2:
% max(X, Y, Y).
% If X is NOT greater than Y,
% result is Y (Y is greater or both are equal).
% This acts as the default/fallback clause.