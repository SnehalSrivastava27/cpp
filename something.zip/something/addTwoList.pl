start :-
    write('Enter first list: '),
    read(L1),

    write('Enter second list: '),
    read(L2),

    conc(L1, L2, L3),

    write('Concatenated list is: '),
    write(L3).

conc([], L2, L2).
conc([H|T], L2, [H|R]) :-
    conc(T, L2, R).

% conc/3 is a predicate used to concatenate two lists.
% It takes three arguments: conc(List1, List2, Result)

% -------------------------------------------
% BASE CASE:
% conc([], L2, L2).
%
% When the first list is empty ([]),
% the result is directly unified with the second list (L2).
% No further recursion is needed.
% Example: conc([], [3,4], [3,4]) is TRUE.
% -------------------------------------------

% -------------------------------------------
% RECURSIVE CASE:
% conc([H|T], L2, [H|R]) :-
%     conc(T, L2, R).
%
% The first list is pattern-matched as [H|T],
% where H is the Head (first element)
% and T is the Tail (remaining elements).
%
% The result list starts with the same Head H,
% followed by R, which is yet to be determined.
%
% Prolog then recursively calls conc(T, L2, R),
% each time stripping the head of List1
% and appending it to the front of the result.
%
% This recursion continues until List1 becomes []
% at which point the base case fires and L2
% is directly placed as the remaining result.
% -------------------------------------------

% -------------------------------------------
% STEP-BY-STEP TRACE EXAMPLE:
% conc([1,2], [3,4], R)
%
% Step 1: conc([1|[2]], [3,4], [1|R1])
%             calls conc([2], [3,4], R1)
%
% Step 2: conc([2|[]], [3,4], [2|R2])
%             calls conc([], [3,4], R2)
%
% Step 3: conc([], [3,4], [3,4])   <- BASE CASE
%             R2 = [3,4]
%
% Unwinding:
%     R1 = [2|R2] = [2,3,4]
%     R  = [1|R1] = [1,2,3,4]
%
% Final Result: R = [1,2,3,4]
% -------------------------------------------