start :-
    write('Enter list: '),
    read(L),

    write('Enter position to delete: '),
    read(N),

    delete(N, L, R),

    write('New list is: '),
    write(R).

delete(1, [_|T], T).
delete(N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    delete(N1, T, R).

% delete/3 is a predicate used to delete an element
% from a specific position in a list.
% It takes three arguments: delete(Position, List, Result)

% -------------------------------------------
% BASE CASE:
% delete(1, [_|T], T).
%
% When the position N reaches 1,
% the head of the list (_) is ignored (discarded),
% and the result is unified with the Tail (T).
% The underscore (_) means we don't care about
% the value at that position, we just remove it.
% Example: delete(1, [10,20,30], R) → R = [20,30]
% -------------------------------------------

% -------------------------------------------
% RECURSIVE CASE:
% delete(N, [H|T], [H|R]) :-
%     N > 1,
%     N1 is N - 1,
%     delete(N1, T, R).
%
% When position N is greater than 1,
% the current Head (H) is NOT the target,
% so it is kept and prepended to the result.
%
% N1 is calculated as N - 1,
% reducing the position by 1 at each step.
%
% Prolog recursively calls delete(N1, T, R),
% moving deeper into the list
% until position becomes 1 (base case).
% -------------------------------------------

% -------------------------------------------
% STEP-BY-STEP TRACE EXAMPLE:
% delete(3, [10,20,30,40], R)
%
% Step 1: N=3 > 1, keep H=10
%             N1 = 3-1 = 2
%             calls delete(2, [20,30,40], R1)
%             Result so far: [10|R1]
%
% Step 2: N=2 > 1, keep H=20
%             N1 = 2-1 = 1
%             calls delete(1, [30,40], R2)
%             Result so far: [10,20|R2]
%
% Step 3: N=1, BASE CASE fires
%             Head 30 is discarded (_)
%             R2 = [40]
%
% Unwinding:
%     R1 = [20|R2] = [20,40]
%     R  = [10|R1] = [10,20,40]
%
% Final Result: R = [10,20,40]
% (element at position 3 is deleted)
% -------------------------------------------