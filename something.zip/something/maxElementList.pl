start :-
    write('Enter a list: '),
    read(L),

    maxlist(L, M),

    write('Maximum element is: '),
    write(M).

maxlist([X], X).
maxlist([H|T], M) :-
    maxlist(T, M1),
    (H > M1 -> M = H ; M = M1).

% ============================================================
% MAX ELEMENT IN LIST
% ============================================================

% maxlist/2 finds the maximum element in a list.
% maxlist(List, Max)

% BASE CASE:
% maxlist([X], X).
% A single-element list — that element itself is the maximum.

% RECURSIVE CASE:
% maxlist([H|T], M) :-
%     maxlist(T, M1),
%     (H > M1 -> M = H ; M = M1).
% Recursively find maximum M1 of the Tail (T).
% Compare Head H with M1 using if-then-else:
%     If H > M1 → M = H (head is bigger)
%     Else      → M = M1 (tail's max is bigger)

% TRACE: maxlist([3,1,4,2], M)
% maxlist([1,4,2], M1)
%   maxlist([4,2], M2)
%     maxlist([2], M3) → M3 = 2   ← BASE
%     4 > 2 → M2 = 4
%   1 > 4? No → M1 = 4
% 3 > 4? No  → M  = 4