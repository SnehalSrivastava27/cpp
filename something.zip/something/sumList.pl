start :-
    write('Enter a list: '),
    read(L),

    sumlist(L, S),

    write('Sum of list is: '),
    write(S).

sumlist([], 0).
sumlist([H|T], S) :-
    sumlist(T, S1),
    S is H + S1.

% ============================================================
% SUM OF LIST
% ============================================================

% sumlist/2 computes the sum of all elements in a list.
% sumlist(List, Sum)

% BASE CASE:
% sumlist([], 0).
% Sum of an empty list is 0.
% Recursion stops here.

% RECURSIVE CASE:
% sumlist([H|T], S) :-
%     sumlist(T, S1),
%     S is H + S1.
% Head H is separated from Tail T.
% Recursively compute sum of Tail into S1.
% Add Head H to S1 to get total sum S.

% TRACE: sumlist([1,2,3], S)
% sumlist([2,3], S1)
%   sumlist([3], S2)
%     sumlist([], S3) → S3 = 0   ← BASE
%     S2 = 3 + 0 = 3
%   S1 = 2 + 3 = 5
% S  = 1 + 5 = 6