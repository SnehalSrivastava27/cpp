start :-
    write('Enter first number: '),
    read(N1),

    write('Enter second number: '),
    read(N2),

    sum(N1, N2, R),

    write('Sum is: '),
    write(R).

    sum(N1, N2, R) :-
    R is N1 + N2.

% ============================================================
% SUM OF TWO NUMBERS
% ============================================================

% sum/3 adds two numbers.
% sum(N1, N2, R)

% SINGLE CLAUSE:
% sum(N1, N2, R) :-
%     R is N1 + N2.
% No recursion needed.
% Prolog's built-in 'is' evaluates the arithmetic expression.
% R is directly unified with the value of N1 + N2.