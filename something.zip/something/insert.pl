start :-
    write('Enter list: '),
    read(L),

    write('Enter element to insert: '),
    read(I),

    write('Enter position: '),
    read(N),

    insert(I, N, L, R),

    write('New list is: '),
    write(R).

insert(I, 1, L, [I|L]).
insert(I, N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    insert(I, N1, T, R).

% ============================================================
% INSERT
% ============================================================

% insert/4 inserts element at a given position in a list.
% insert(Element, Position, List, Result)

% BASE CASE:
% insert(I, 1, L, [I|L]).
% When position reaches 1,
% element I is directly prepended to remaining list L.
% Example: insert(99, 1, [1,2,3], R) → R = [99,1,2,3]

% RECURSIVE CASE:
% insert(I, N, [H|T], [H|R]) :-
%     N > 1,
%     N1 is N - 1,
%     insert(I, N1, T, R).
% When N > 1, current Head H is not the target position.
% H is kept in result as-is.
% Position is decremented by 1 and recursion goes deeper.

% TRACE: insert(99, 3, [1,2,3,4], R)
% Step 1: N=3>1, keep H=1, call insert(99,2,[2,3,4],R1)
% Step 2: N=2>1, keep H=2, call insert(99,1,[3,4],R2)
% Step 3: N=1, BASE → R2 = [99,3,4]
% Unwind:  R1 = [2,99,3,4]
%          R  = [1,2,99,3,4]